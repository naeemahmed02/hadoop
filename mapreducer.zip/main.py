import re
import json
from mrjob.job import MRJob, MRStep


class WordCounter(MRJob):

    def mapper(self, key, value):
        review = json.loads(value)
        review_text = review.get('reviewText', '')

        tokens = re.findall(r"\b\w+\b", review_text.lower())

        for token in tokens:
            yield token, 1

    
    def combiner(self, key, values):
        yield key, sum(values)

    def reducer(self, key, values):
        # yield key, sum(values)
        yield None, (sum(values), key)

    def sort_reducer(self, _, word_count_pairs):
        for count, word in sorted(word_count_pairs, reverse=True):
            yield word, count
    
    def steps(self):
        return [
            MRStep(
                mapper= self.mapper, combiner = self.combiner,reducer = self.reducer
            ),
            MRStep(reducer = self.sort_reducer)
        ]


if __name__ == '__main__':
    WordCounter.run()
