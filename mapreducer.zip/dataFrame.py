import pandas as pd

data = []
with open("politics_output.txt", "r", encoding="utf-16") as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        parts = line.replace('"', '').split('\t')
        if len(parts) == 2:
            word, count = parts
            # Clean up null bytes
            count = count.replace('\x00', '')
            word = word.replace('\x00', '')
            try:
                data.append((word, int(count)))
            except ValueError:
                print("Skipping invalid:", word, count)

df = pd.DataFrame(data, columns=["word", "count"])
df = df.sort_values(by="count", ascending=False).reset_index(drop=True)

print(df.head(10))

import seaborn as sns
import matplotlib.pyplot as plt

top_df = df.head(50)

plt.figure(figsize=(12, 6))
sns.barplot(x='word', y='count', data=top_df, palette='viridis')
plt.xticks(rotation=90, ha='right')
plt.xlabel('Word')
plt.ylabel('Count')
plt.title('Top 20 Most Frequent Words')
plt.tight_layout()
plt.show()
